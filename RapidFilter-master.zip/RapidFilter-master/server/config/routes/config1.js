module.exports = {
	mongo:{
			
			url:'mongodb://localhost/mydb_Auth'
	},
	server:{
		
		host:'127.0.0.1',
		port:9999
	}

};
